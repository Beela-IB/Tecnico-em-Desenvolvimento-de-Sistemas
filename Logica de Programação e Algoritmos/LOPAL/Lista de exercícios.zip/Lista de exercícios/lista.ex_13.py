#Leia n ́umeros at ́e o usu ́ario digitar -1. Exiba a m ́edia dos valores.
numero = 0
soma = 0
qtd = 0
while(numero != -1):
    numero = int(input("Digite um número: "))
    
    if(numero != -1):
        soma = soma + numero
        qtd = qtd + 1

media = soma/qtd

print(media)